$(function () {
    function setStyle(font) {
        let oldDtyleDom = $('style#font-changer-style')
        if (oldDtyleDom) {
            oldDtyleDom.remove()
        }
        let styleDom = $('<style></style>').attr('id', 'font-changer-style')
        styleDom.text(`@font-face {
            font-family: 'Hangyaku';
            src: url('${chrome.runtime.getURL('fonts/Hangyaku.ttf')}');
        }
        @font-face {
            font-family: 'cube12';
            src: url('${chrome.runtime.getURL('fonts/cube12.ttf')}');
        }
        @font-face {
            font-family: 'comicsans';
            src: url('${chrome.runtime.getURL('fonts/comicsans.ttf')}');
        }
        @font-face {
            font-family: 'dsdigi';
            src: url('${chrome.runtime.getURL('fonts/DS-DIGI.TTF')}');
        }
        @font-face {
            font-family: 'aamonoline';
            src: url('${chrome.runtime.getURL('fonts/Aamonoline.ttf')}');
        }
        @font-face {
            font-family: 'papyrus';
            src: url('${chrome.runtime.getURL('fonts/papyrus.ttf')}');
        }
        @font-face {
            font-family: 'makapop';
            src: url('${chrome.runtime.getURL('fonts/851MkPOP_101.ttf')}');
        }
        @font-face {
            font-family: 'tanuki';
            src: url('${chrome.runtime.getURL('fonts/TanukiMagic.ttf')}');
        }
        @font-face {
            font-family: 'tamanegi';
            src: url('${chrome.runtime.getURL('fonts/tamanegi_kaisho.ttf')}');
        }
        @font-face {
            font-family: 'tamanegigeki';
            src: url('${chrome.runtime.getURL('fonts/玉ねぎ楷書激.ttf')}');
        }

        * {
            font-family: ${font} !important
        }`)
        $('head').append(styleDom)
    }

    async function getSettings() {
        let fonts = []
        await chrome.storage.sync.get(null, data => {
            for (const key in data) {
                fonts.push(data[key])
            }
            if (fonts) {
                let font = fonts.join(', ')
                setStyle(font)
            }
        })
    }
    getSettings()

    chrome.storage.onChanged.addListener(getSettings)
})