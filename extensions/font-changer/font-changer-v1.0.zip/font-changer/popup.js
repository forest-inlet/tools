$(() => {
    $('.font').each(function () {
        let font = $(this).attr('id')
        $(this).css('font-family', font)
    })

    chrome.storage.sync.get(null, data => {
        if (data) {
            for (const key in data) {
                $(`#${data[key]} button.move`).click()
            }
        }
    })

    $("#selected").sortable({
        placeholder: "sortable-placeholder", // ドロップ位置を視覚的に示す
        helper: "clone", // ドラッグ中のアイテムを複製
        opacity: 0.8,
        start: function (event, ui) {
            ui.item.addClass("dragging")
        },
        stop: function (event, ui) {
            ui.item.removeClass("dragging")
            setSettings()
        }
    }).disableSelection()

    $('.move').on('click', function () {
        let item = $(this).parent()
        let parent = item.parent()
        item.detach()
        if (parent.attr('id') === 'selected') {
            $('#unselected').append(item)
            $(this).text('o')
        } else {
            $('#selected').append(item)
            $(this).text('x')
        }
        setSettings()
    })

    function setSettings() {
        let fonts = {}
        let selectedDom = $('#selected .font')
        if (selectedDom) {
            selectedDom.each(function (index) {
                fonts[index + 1] = $(this).attr('id')
            })
        }
        chrome.storage.sync.clear()
        chrome.storage.sync.set(fonts)
    }
})